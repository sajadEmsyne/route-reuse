import {
    RouteReuseStrategy,
    ActivatedRouteSnapshot,
    DetachedRouteHandle,
} from '@angular/router';

export class CustomRouteReuseStrategy implements RouteReuseStrategy {
    private storedHandles = new Map<string, DetachedRouteHandle>();

    shouldDetach(route: ActivatedRouteSnapshot): boolean {
        return route.routeConfig?.data?.['reuse'] === true;
    }

    store(route: ActivatedRouteSnapshot, handle: DetachedRouteHandle): void {
        const key = this.getRouteKey(route);
        this.storedHandles.set(key, handle);
    }

    shouldAttach(route: ActivatedRouteSnapshot): boolean {
        const key = this.getRouteKey(route);
        return this.storedHandles.has(key);
    }

    retrieve(route: ActivatedRouteSnapshot): DetachedRouteHandle | null {
        const key = this.getRouteKey(route);
        return this.storedHandles.get(key) || null;
    }

    shouldReuseRoute(
        future: ActivatedRouteSnapshot,
        curr: ActivatedRouteSnapshot
    ): boolean {
        return future.routeConfig === curr.routeConfig;
    }

    private getRouteKey(route: ActivatedRouteSnapshot): string {
        return route.pathFromRoot.map((r) => r.url.join('/')).join('/');
    }
}