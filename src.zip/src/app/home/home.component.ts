import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

  private _fb = inject(FormBuilder);
  homeForm !: FormGroup;
  private _router = inject(Router); 

  genderList = [
    { name: 'Male', id: 1 },
    { name: 'Female', id: 2 },
    { name: 'Prefer not to Say', id: 3 }
  ]
  constructor() {
    this.homeForm = this._fb.group({
      userName: [''],
      gender: [''],
      address: ['']
    })
  }

  ngOnInit(){
    console.log("Home component Created")
  }

  submitForm() {
    console.log(this.homeForm.value,"Value")
  }

  redirectToAbout(){
    this._router.navigate(['/about'])
  }

  ngOnDestroy(){
    console.log("Home component destroyed")
  }
}
