import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [],
  templateUrl: './about.component.html',
  styleUrl: './about.component.css'
})
export class AboutComponent {
  private _router = inject(Router)
  ngOnInit(){
    console.log("About component Created")
  }

  redirectToCareer(){
    this._router.navigate(['/career'])
  }
  ngOnDestroy(){
    console.log("About component destroyed")
  }
}
